<?php
/**
 * Register the custom product type after init
 */
function register_tour_product_type() {
    class WC_Product_Tour extends WC_Product {
        public function __construct( $product ) {
            $this->product_type = 'tour';
            parent::__construct( $product );
        }
    }
}
add_action( 'plugins_loaded', 'register_tour_product_type' );
/**
 * Add to product type drop down.
 */
function add_tour_product( $types ){
    // Key should be exactly the same as in the class
    $types[ 'tour' ] = __( 'Tour product' );
    return $types;
}
add_filter( 'product_type_selector', 'add_tour_product' );
/**
 * Show pricing fields for tour product.
 */
function tour_custom_js() {
    if ( 'product' != get_post_type() ) :
        return;
    endif;
    ?><script type='text/javascript'>
        jQuery( document ).ready( function() {
            var selectValue = jQuery('#product-type').val();
            if(selectValue == 'tour'){
                jQuery('ul.product_data_tabs li').removeClass('active');
                jQuery( '.general_options' ).addClass('active');
                jQuery( '.general_options' ).show();

                jQuery('.panel-wrap.product_data .panel').hide();
                jQuery('#general_product_data,.options_group.pricing').show();
            }
            jQuery('#product-type').on('change', function() {
                if(jQuery(this).val() == 'tour'){
                    jQuery('ul.product_data_tabs li').removeClass('active');
                    jQuery( '.general_options' ).addClass('active');
                    jQuery( '.general_options' ).show();

                    jQuery('.panel-wrap.product_data .panel').hide();
                    jQuery('#general_product_data,.options_group.pricing').show();
                }
            });
        });
    </script><?php
}
add_action( 'admin_footer', 'tour_custom_js' );
/**
 * Hide Attributes data panel.
 */
function hide_attributes_data_panel( $tabs) {
    $tabs['attribute']['class'][] = 'hide_if_tour hide_if_variable_rental';
    return $tabs;
}
add_filter( 'woocommerce_product_data_tabs', 'hide_attributes_data_panel' );

// Register Tour Taxonomy
add_action( 'init', 'tour_category_taxonomy' );
function tour_category_taxonomy()  {
    $labels = array(
        'name'                       => 'Tour Categories',
        'singular_name'              => 'Tour Category',
        'menu_name'                  => 'Tour Categories',
        'all_items'                  => 'All Tour Categories',
        'parent_item'                => 'Parent Tour Category',
        'parent_item_colon'          => 'Parent Tour Category:',
        'new_item_name'              => 'New Tour Category',
        'add_new_item'               => 'Add Tour Category',
        'edit_item'                  => 'Edit Tour Category',
        'update_item'                => 'Update Tour Category',
        'separate_items_with_commas' => 'Separate Tour Category with commas',
        'search_items'               => 'Search Tour Category',
        'add_or_remove_items'        => 'Add or remove Tour Category',
        'choose_from_most_used'      => 'Choose from the most used Tour Category',
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => false,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => false,
        'rewrite'                   => array(
            'slug' => 'tour/category',
            'hierarchical' => true
        )
    );
    register_taxonomy( 'tour_category', 'product', $args );
    register_taxonomy_for_object_type( 'tour_category', 'product' );
}
// Register Destination Taxonomy
add_action( 'init', 'tour_destination_taxonomy' );
function tour_destination_taxonomy()  {
    $labels = array(
        'name'                       => 'Tour Destinations',
        'singular_name'              => 'Tour Destination',
        'menu_name'                  => 'Tour Destinations',
        'all_items'                  => 'All Tour Destinations',
        'parent_item'                => 'Parent Tour Destination',
        'parent_item_colon'          => 'Parent Tour Destination:',
        'new_item_name'              => 'New Tour Destination',
        'add_new_item'               => 'Add Tour Destination',
        'edit_item'                  => 'Edit Tour Destination',
        'update_item'                => 'Update Tour Destination',
        'separate_items_with_commas' => 'Separate Tour Destination with commas',
        'search_items'               => 'Search Tour Destination',
        'add_or_remove_items'        => 'Add or remove Tour Destination',
        'choose_from_most_used'      => 'Choose from the most used Tour Destination',
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => false,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => false,
        'rewrite'                   => array(
            'slug' => 'tour/destination',
            'hierarchical' => true
        )
    );
    register_taxonomy( 'tour_destination', 'product', $args );
    register_taxonomy_for_object_type( 'tour_destination', 'product' );
}
// New Wishlist End Point
function efora_wishlist_menu_items( $items ) {
    // Remove the logout menu item.
    $logout = $items['customer-logout'];
    unset( $items['customer-logout'] );
    $items['wishlist'] = __( 'Wishlist', 'efora' );
    // Insert back the logout item.
    $items['customer-logout'] = $logout;
    return $items;
}
add_filter( 'woocommerce_account_menu_items', 'efora_wishlist_menu_items', 10, 1 );
function efora_wishlist_endpoint() {
    add_rewrite_endpoint( 'wishlist', EP_PAGES );
}
add_action( 'init', 'efora_wishlist_endpoint' );
/**
 * Helper: is endpoint
 */
function wishlist_is_endpoint( $endpoint = false ) {
    global $wp_query;
    if( !$wp_query )
        return false;
    return isset( $wp_query->query[ $endpoint ] );
}