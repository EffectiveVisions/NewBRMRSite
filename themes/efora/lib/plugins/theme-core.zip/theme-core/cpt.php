<?php // FAQ CPT
function faq_cpt() {
    register_post_type( 'efora-faq',
        array(
            'labels' => array(
                'name' => 'FAQs',
                'singular_name' => 'FAQ',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New FAQ',
                'edit' => 'Edit',
                'edit_item' => 'Edit FAQ',
                'new_item' => 'New FAQ',
                'view' => 'View',
                'view_item' => 'View FAQ',
                'search_items' => 'Search FAQ',
                'not_found' => 'No FAQ found',
                'not_found_in_trash' => 'No FAQ found in Trash',
                'parent' => 'Parent FAQ'
            ),

            'public' => true,
            'supports' => array( 'title','editor'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'has_archive' => true,
            'exclude_from_search' => true,
            'rewrite'                   => array(
                'slug' => 'faq',
                'hierarchical' => true
            )
        )
    );
}
add_action( 'init', 'faq_cpt' );
// Guides CPT
function guides_cpt() {
    register_post_type( 'efora-guides',
        array(
            'labels' => array(
                'name' => 'Guides',
                'singular_name' => 'Guide',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Guide',
                'edit' => 'Edit',
                'edit_item' => 'Edit Guide',
                'new_item' => 'New Guide',
                'view' => 'View',
                'view_item' => 'View Guide',
                'search_items' => 'Search Guide',
                'not_found' => 'No Guide found',
                'not_found_in_trash' => 'No Guide found in Trash',
                'parent' => 'Parent Guide'
            ),

            'public' => true,
            'supports' => array( 'title','thumbnail'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'has_archive' => true,
            'exclude_from_search' => true,
            'rewrite'                   => array(
                'slug' => 'guide',
                'hierarchical' => true
            )
        )
    );
}
add_action( 'init', 'guides_cpt' );