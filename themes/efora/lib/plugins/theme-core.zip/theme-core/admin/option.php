<?php
$plugin_path = plugins_url('theme-core');
return array(
	'title' => __('THEME OPTIONS', 'theme-core'),
	'logo' => $plugin_path.'/admin/logo.png',
    'menus' => array(
        array(
            'title' => esc_html__('General Settings', 'theme-core'),
            'name' => 'menu_1',
            'icon' => 'font-awesome:fa-magic',
            'menus' => array(
                array(
                    'title' => esc_html__('Header', 'theme-core'),
                    'name' => 'header',
                    'icon' => 'font-awesome:fa-th-large',
                    'controls' => array(
                        // Logo Image Section
                        array(
                            'type' => 'section',
                            'title' => esc_html__('Logo Image', 'theme-core'),
                            'name' => 'image_logo_section',
                            'description' => esc_html__('Upload or select logo for header.', 'theme-core'),
                            'fields' => array(
                                array(
                                    'type' => 'upload',
                                    'name' => 'default_logo',
                                    'label' => esc_html__('Default Header Logo', 'theme-core'),
                                    'description' => esc_html__('Upload or choose custom logo.', 'theme-core'),
                                ),
                                array(
                                    'type' => 'upload',
                                    'name' => 'transparent_logo',
                                    'label' => esc_html__('Transparent Header Logo', 'theme-core'),
                                    'description' => esc_html__('Upload or choose custom logo.', 'theme-core'),
                                )
                            ),
                        ),
                        // Other Details Section
                        array(
                            'type' => 'section',
                            'title' => esc_html__('Other Details', 'theme-core'),
                            'name' => 'other_section',
                            'description' => esc_html__('Other Details', 'theme-core'),
                            'fields' => array(
                                // General Pages Menu
                                array(
                                    'type' => 'select',
                                    'name' => 'header_menu_type',
                                    'label' => esc_html__('General Pages Menu', 'theme-core'),
                                    'items' => array(
                                        array(
                                            'value' => 'default',
                                            'label' => esc_html__('Default', 'theme-core'),
                                        ),
                                        array(
                                            'value' => 'default-absolute',
                                            'label' => esc_html__('Default Absolute', 'theme-core'),
                                        ),
                                        array(
                                            'value' => 'transparent-menu',
                                            'label' => esc_html__('Transparent Menu', 'theme-core'),
                                        ),
                                    ),
                                    'default' => array(
                                        'default',
                                    ),
                                ),
                                // Header Phone
                                array(
                                    'type' => 'textbox',
                                    'name' => 'header_phone',
                                    'label' => esc_html__('Header Phone', 'theme-core')
                                ),
                                // Header Feature Text
                                array(
                                    'type' => 'textbox',
                                    'name' => 'header_feature_txt',
                                    'label' => esc_html__('Header Feature Text', 'theme-core')
                                ),
                                // Hide Top Search
                                array(
                                    'type' => 'toggle',
                                    'name' => 'topSearch',
                                    'label' => esc_html__('Hide Top Search', 'theme-core'),
                                    'description' => esc_html__('You can disable top search for header.', 'theme-core'),
                                    'default' => '0',
                                ),
                                // Hide Top Account Option
                                array(
                                    'type' => 'toggle',
                                    'name' => 'topAccount',
                                    'label' => esc_html__('Hide Top Account Option', 'theme-core'),
                                    'description' => esc_html__('You can disable top account option for header.', 'theme-core'),
                                    'default' => '0',
                                ),
                                // Facebook Login Link/Shortcode
                                array(
                                    'type' => 'textbox',
                                    'name' => 'facebookLogin',
                                    'label' => esc_html__('Facebook Login Link/Shortcode', 'theme-core'),
                                    'description' => esc_html__('Facebook login link or shortcode for account overlay.', 'theme-core')
                                ),
                                // Twitter Login Link/Shortcode
                                array(
                                    'type' => 'textbox',
                                    'name' => 'twitterLogin',
                                    'label' => esc_html__('Twitter Login Link/Shortcode', 'theme-core'),
                                    'description' => esc_html__('Twitter login link or shortcode for account overlay.', 'theme-core')
                                ),
                                // Google Plus Login Link/Shortcode
                                array(
                                    'type' => 'textbox',
                                    'name' => 'googleLogin',
                                    'label' => esc_html__('Google Login Link/Shortcode', 'theme-core'),
                                    'description' => esc_html__('Google login link or shortcode for account overlay.', 'theme-core')
                                ),
                                // Signup Image
                                array(
                                    'type' => 'upload',
                                    'name' => 'signImage',
                                    'label' => esc_html__('Signup Overlay Image', 'theme-core'),
                                    'default' => '',
                                ),
                                // Disable Site Loader
                                array(
                                    'type' => 'toggle',
                                    'name' => 'disableLoader',
                                    'label' => esc_html__('Disable Site Loader', 'theme-core'),
                                    'description' => esc_html__('You can disable site preloader image.', 'theme-core'),
                                    'default' => '0',
                                ),
                                // Site Pre-loader Image
                                array(
                                    'type' => 'upload',
                                    'name' => 'preLoader',
                                    'label' => esc_html__('PreLoader Image', 'theme-core'),
                                    'default' => '',
                                ),
                                // Custom JS
                                array(
                                    'type' => 'codeeditor',
                                    'name' => 'custom_js',
                                    'label' => esc_html__('Custom JS', 'theme-core'),
                                    'description' => esc_html__('Write your custom js here.', 'theme-core'),
                                    'theme' => 'twilight',
                                    'mode' => 'javascript',
                                ),
                                // Footer Copyright
                                array(
                                    'type' => 'textbox',
                                    'name' => 'footer_copyright',
                                    'label' => esc_html__('Copyright Text', 'theme-core'),
                                    'description' => esc_html__('Only alphabets and numbers allowed here.', 'theme-core'),
                                    'default' => esc_html__('Copyright &copy; 2017 efora. All rights reserved.', 'theme-core')
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
        // Styling Options
        array(
            'title' => esc_html__('Styling Options', 'theme-core'),
            'name' => 'styling_options',
            'icon' => 'font-awesome:fa-gift',
            'controls' => array(
                // Heading Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Headings', 'theme-core'),
                    'fields' => array(
                        // Heading H1
                        array(
                            'type' => 'color',
                            'name' => 'heading_h1',
                            'label' => esc_html__('Heading H1', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H2
                        array(
                            'type' => 'color',
                            'name' => 'heading_h2',
                            'label' => esc_html__('Heading H2', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H3
                        array(
                            'type' => 'color',
                            'name' => 'heading_h3',
                            'label' => esc_html__('Heading H3', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H4
                        array(
                            'type' => 'color',
                            'name' => 'heading_h4',
                            'label' => esc_html__('Heading H4', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H5
                        array(
                            'type' => 'color',
                            'name' => 'heading_h5',
                            'label' => esc_html__('Heading H5', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                        // Heading H6
                        array(
                            'type' => 'color',
                            'name' => 'heading_h6',
                            'label' => esc_html__('Heading H6', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set heading color.', 'theme-core'),
                        ),
                    ),
                ),
                // Header Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Header', 'theme-core'),
                    'fields' => array(
                        // Default Menu Color
                        array(
                            'type' => 'color',
                            'name' => 'd_menu_color',
                            'label' => esc_html__('Default menu Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set menu color.', 'theme-core'),
                        ),
                        // Transparent Menu Color
                        array(
                            'type' => 'color',
                            'name' => 't_menu_color',
                            'label' => esc_html__('Transparent Menu Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set transparent menu color.', 'theme-core'),
                        )
                    ),
                ),
                // Body Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Body', 'theme-core'),
                    'fields' => array(
                        // Default Yellow Color
                        array(
                            'type' => 'color',
                            'name' => 'default_y_color',
                            'label' => esc_html__('Default Yellow Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can change default yellow color.', 'theme-core'),
                        ),
                        // Default Orange Color
                        array(
                            'type' => 'color',
                            'name' => 'default_o_color',
                            'label' => esc_html__('Default Orange Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can change default orange color.', 'theme-core'),
                        ),
                        // Body Color
                        array(
                            'type' => 'color',
                            'name' => 'body_color',
                            'label' => esc_html__('Body Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set body color, general p tag.', 'theme-core'),
                        ),
                    ),
                ),
                // Footer Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Footer', 'theme-core'),
                    'fields' => array(
                        // Footer Background Color
                        array(
                            'type' => 'color',
                            'name' => 'footer_default_bg',
                            'label' => esc_html__('Footer Background Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set footer default background color.', 'theme-core'),
                        ),
                        // Footer Default Color
                        array(
                            'type' => 'color',
                            'name' => 'footer_default_color',
                            'label' => esc_html__('Footer Default Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set footer default color.', 'theme-core'),
                        )
                    ),
                ),
                // Other Styling
                array(
                    'type' => 'section',
                    'title' => esc_html__('Other Styling', 'theme-core'),
                    'fields' => array(
                        // Links Color
                        array(
                            'type' => 'color',
                            'name' => 'links_normal',
                            'label' => esc_html__('Links Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set links color.', 'theme-core'),
                        ),
                        // Links Color
                        array(
                            'type' => 'color',
                            'name' => 'links_hover',
                            'label' => esc_html__('Links Hover Color', 'theme-core'),
                            'description' => esc_html__('Color Picker, you can set links hover color.', 'theme-core'),
                        )
                    ),
                ),
            ),
        ),
        // Typography Options
        array(
            'title' => esc_html__('Typography Options', 'theme-core'),
            'name' => 'typo_options',
            'icon' => 'font-awesome:fa-text-width',
            'controls' => array(
                // Headings Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Headings Font Family', 'theme-core'),
                    'fields' => array(
                        array(
                            'type' => 'select',
                            'name' => 'headings_font_face',
                            'label' => esc_html__('Headings Font Face: h1,h2,h3', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'function',
                                        'value' => 'vp_get_gwf_family',
                                    ),
                                ),
                            ),
                            //'default' => '{{first}}'
                        ),
                        array(
                            'type' => 'radiobutton',
                            'name' => 'headings_font_weight',
                            'label' => esc_html__('Headings Font Weight', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'binding',
                                        'field' => 'headings_font_face',
                                        'value' => 'vp_get_gwf_weight',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
                // Meta Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Meta Data Font Family', 'theme-core'),
                    'fields' => array(
                        array(
                            'type' => 'select',
                            'name' => 'meta_font_face',
                            'label' => esc_html__('Meta Data Font Face: h4,h5,h6, widget title etc.', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'function',
                                        'value' => 'vp_get_gwf_family',
                                    ),
                                ),
                            ),
                            //'default' => '{{first}}'
                        ),
                        array(
                            'type' => 'radiobutton',
                            'name' => 'meta_font_weight',
                            'label' => esc_html__('Meta Data Font Weight', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'binding',
                                        'field' => 'meta_font_face',
                                        'value' => 'vp_get_gwf_weight',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
                // Body Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Body Font Family', 'theme-core'),
                    'fields' => array(
                        array(
                            'type' => 'select',
                            'name' => 'body_font_face',
                            'label' => esc_html__('Body Font Face', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'function',
                                        'value' => 'vp_get_gwf_family',
                                    ),
                                ),
                            ),
                            //'default' => '{{first}}'
                        ),
                        array(
                            'type' => 'radiobutton',
                            'name' => 'body_font_weight',
                            'label' => esc_html__('Body Font Weight', 'theme-core'),
                            'items' => array(
                                'data' => array(
                                    array(
                                        'source' => 'binding',
                                        'field' => 'body_font_face',
                                        'value' => 'vp_get_gwf_weight',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
                // Font Sizes Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('Font Sizes', 'theme-core'),
                    'fields' => array(
                        // Body Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'body_font_size',
                            'label'   => esc_html__('Body Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H1 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h1_font_size',
                            'label'   => esc_html__('H1 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H2 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h2_font_size',
                            'label'   => esc_html__('H2 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H3 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h3_font_size',
                            'label'   => esc_html__('H3 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H4 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h4_font_size',
                            'label'   => esc_html__('H4 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H5 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h5_font_size',
                            'label'   => esc_html__('H5 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // H6 Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'h6_font_size',
                            'label'   => esc_html__('H6 Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        ),
                        // Menu Font Size
                        array(
                            'type'    => 'slider',
                            'name'    => 'menu_font_size',
                            'label'   => esc_html__('Menu Font Size (px)', 'theme-core'),
                            'min'     => '0',
                            'max'     => '100',
                            'step'    => '1',
                        )
                    ),
                ),
            ),
        ),
        // Single Page Options
        array(
            'title' => esc_html__('Post Page Options', 'theme-core'),
            'name' => 'post_options',
            'icon' => 'font-awesome:fa-files-o',
            'controls' => array(
                // Page Post Options
                array(
                    'type' => 'section',
                    'title' => esc_html__('Single Page Details', 'theme-core'),
                    'fields' => array(
                        // Single Post Parallax Image
                        array(
                            'type' => 'upload',
                            'name' => 'singleParallax',
                            'label' => esc_html__('Single Post Parallax Image, set and feature image will be override.', 'theme-core'),
                        ),
                        // Hide Feature Image
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_socialshare',
                            'label' => esc_html__('Hide Social Share', 'theme-core'),
                            'description' => esc_html__('You can hide social shares for single posts.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Complete Header
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_cHeader',
                            'label' => esc_html__('Hide Complete Header', 'theme-core'),
                            'description' => esc_html__('You can hide parallax banner for single posts.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Meta Data
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_meta_data',
                            'label' => esc_html__('Hide Meta Data', 'theme-core'),
                            'description' => esc_html__('You can hide meta data for single posts.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Secondary Title
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_secondary_title',
                            'label' => esc_html__('Hide Secondary Title', 'theme-core'),
                            'description' => esc_html__('You can hide second title for posts.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Hide Next/Prev Link
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_next_prev',
                            'label' => esc_html__('Hide Next/Prev Links', 'theme-core'),
                            'description' => esc_html__('You can hide next/prev links for post.', 'theme-core'),
                            'default' => '0',
                        ),
                    ),
                ),
            ),
        ),
        // Woocommerce Page Options
        array(
            'title' => esc_html__('Woocommerce Options', 'theme-core'),
            'name' => 'woo_options',
            'icon' => 'font-awesome:fa-shopping-cart',
            'controls' => array(
                // Page Post Options
                array(
                    'type' => 'section',
                    'title' => esc_html__('Woocommerce Details', 'theme-core'),
                    'fields' => array(
                        // Hide Header Cart
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_head_cart',
                            'label' => esc_html__('Hide Header Cart', 'theme-core'),
                            'description' => esc_html__('You can hide header cart option.', 'theme-core'),
                            'default' => '0',
                        ),
                        // Number Of shop Products
                        array(
                            'type' => 'textbox',
                            'name' => 'number_products',
                            'label' => esc_html__('Number Of Shop Products', 'theme-core'),
                            'default' => '5',
                        ),
                        // Latest Article Heading
                        array(
                            'type' => 'textbox',
                            'name' => 'latest_art_head',
                            'label' => esc_html__('Latest Article Heading', 'theme-core')
                        ),
                        // Latest Article Sub Heading
                        array(
                            'type' => 'textbox',
                            'name' => 'latest_art_shead',
                            'label' => esc_html__('Latest Article Sub Heading', 'theme-core')
                        ),
                        // Latest Article Category ID
                        array(
                            'type' => 'textbox',
                            'name' => 'latest_art_cat',
                            'label' => esc_html__('Latest Article category ID', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core')
                        ),
                    ),
                ),
            ),
        ),
        // Social Options
        array(
            'title' => esc_html__('Social Options', 'theme-core'),
            'name' => 'social_options',
            'icon' => 'font-awesome:fa-facebook',
            'controls' => array(
                // Social Connect
                array(
                    'type' => 'section',
                    'title' => esc_html__('Social Connect', 'theme-core'),
                    'fields' => array(
                        // Facebook
                        array(
                            'type' => 'textbox',
                            'name' => 'facebook',
                            'label' => esc_html__('Facebook', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Twitter
                        array(
                            'type' => 'textbox',
                            'name' => 'twitter',
                            'label' => esc_html__('Twitter', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Linkedin
                        array(
                            'type' => 'textbox',
                            'name' => 'linkedin',
                            'label' => esc_html__('LinkedIn', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core')
                        ),
                        // Pinterest
                        array(
                            'type' => 'textbox',
                            'name' => 'pinterest',
                            'label' => esc_html__('Pinterest', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core')
                        ),
                        // Instagram
                        array(
                            'type' => 'textbox',
                            'name' => 'instagram',
                            'label' => esc_html__('Instagram', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core'),
                            'default' => '#',
                        ),
                        // Youtube
                        array(
                            'type' => 'textbox',
                            'name' => 'youtube',
                            'label' => esc_html__('Youtube', 'theme-core'),
                            'description' => esc_html__('Leave empty if not required.', 'theme-core')
                        ),
                    ),
                ),
            ),
        ),
        // 404 Page Options
        array(
            'title' => esc_html__('404 Page Options', 'theme-core'),
            'name' => 'page404_options',
            'icon' => 'font-awesome:fa-warning',
            'controls' => array(
                // Headings Section
                array(
                    'type' => 'section',
                    'title' => esc_html__('404 Page Details', 'theme-core'),
                    'fields' => array(
                        // Background Image
                        array(
                            'type' => 'upload',
                            'name' => 'background404',
                            'label' => esc_html__('404 page background Image', 'theme-core'),
                        ),
                        // 404 Editor
                        array(
                            'type' => 'codeeditor',
                            'name' => 'error_404',
                            'label' => esc_html__('Page Text', 'theme-core'),
                            'description' => esc_html__('HTML tags are supported.', 'theme-core'),
                            'theme' => 'github',
                            'mode' => 'html',
                        ),
                    ),
                ),
            ),
        ),
    )
);
/**
 *EOF
 */