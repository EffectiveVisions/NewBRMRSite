<?php
// Content filter used ONLY on custom theme shortcodes to remove
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
    // array of custom shortcodes requiring the fix
    $block = join("|",array(
        "",
    ));
// opening tag
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
    return $rep;
}
// Container Shortcode
function container_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['class'])){
        $class = $atts['class'];
    } else {
        $class = '';
    }
    $out = '';
    $out .= '<div class="container '.$class.'">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('container', 'container_shortcode');
// Tour Listing Shortcode
function tour_listing_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['display_style'])){
        $display_style = $atts['display_style'];
    } else {
        $display_style = '';
    }
    if(!empty($atts['tour_categories'])){
        $tour_categories = $atts['tour_categories'];
    } else {
        $tour_categories = '';
    }
    if(!empty($atts['number_of_tours'])){
        $number_of_tours = $atts['number_of_tours'];
    } else {
        $number_of_tours = 5;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }

    $out = '';

    if(!empty($tour_categories)){
        $ex_tour_categories = explode(",",$tour_categories);
        $categories = get_terms( 'tour_category', array(
            'orderby'    => 'count',
            'hide_empty' => 1,
            'include'    => $ex_tour_categories
        ) );
    }else{
        $categories = get_terms( 'tour_category', array(
            'orderby'    => 'count',
            'hide_empty' => 1
        ) );
    }
    // Loop Arguments
    $term_array = array();
    foreach($categories as $cat) {
        $term_array[] = $cat->slug;
    }
    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
    if(!empty($_REQUEST['search-tour'])){
        // Search Parameters
        if(!empty($_REQUEST['tour-destination'])){
            $tour_destination = $_REQUEST['tour-destination'];
        } else {
            $tour_destination = '';
        }
        if(!empty($_REQUEST['tour-category'])){
            $tour_category = $_REQUEST['tour-category'];
        } else {
            $tour_category = '';
        }
        if(!empty($_REQUEST['tour-month'])){
            $tour_month = $_REQUEST['tour-month'];
        } else {
            $tour_month = 'January';
        }
        if(!empty($_REQUEST['tour-duration'])){
            $tour_duration = $_REQUEST['tour-duration'];
        } else {
            $tour_duration = '4 Days';
        }
        $tours = array(
            'post_type' => 'product',
            'posts_per_page' => $number_of_tours,
            'paged' => $paged,
            'order' => $order,
            'tax_query' => array(
                'relation' => 'AND',
                array(
                    'taxonomy' => 'tour_category',
                    'field'    => 'name',
                    'terms'    => $tour_category,
                ),
                array(
                    'taxonomy' => 'tour_destination',
                    'field'    => 'name',
                    'terms'    => $tour_destination,
                ),
            ),
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key'     => 'travel_month_t',
                    'value'   => $tour_month,
                    'compare' => '=',
                ),
                array(
                    'key' => 'tour_duration',
                    'value'   => $tour_duration,
                    'compare' => '=',
                ),
            ),
        );
    } else {
        $tours = array(
            'post_type' => 'product',
            'posts_per_page' => $number_of_tours,
            'paged' => $paged,
            'order' => $order,
            'tax_query' => array(
                array(
                    'taxonomy' => 'tour_category',
                    'field'    => 'slug',
                    'terms'    => $term_array,
                ),
            ),
        );
    }
    $tours_loop = new WP_Query($tours);
    if($display_style == '4-col-outer-meta'){
        $out .= '<div class="tg-listing tg-listingvfive woocommerce">';
    } elseif($display_style == '3-col-inner-meta'){
        $out .= '<div class="tg-listing tg-listingvtwo woocommerce">';
    } elseif($display_style == '2-col-inner-meta-only'){
        $out .= '<div class="tg-listing tg-listingvfour woocommerce">';
    } elseif($display_style == 'single-row-side-info'){
        $out .= '<div class="tg-listing tg-listingvthree woocommerce">';
    } elseif($display_style == 'single-row-below-info'){
        $out .= '<div class="tg-listing tg-listingvsix woocommerce">';
    } else {
        $out .= '<div class="tg-listing tg-listingvone woocommerce">';
    }
    $count = 1;
    if(!empty($_REQUEST['tour-destination'])){
        $out .= '<div class="tg-sectiontitle "><h2>'.$_REQUEST['tour-destination'].' '.esc_html__('Tours','efora').'</h2></div><div class="clearfix"></div>';
    }
    if($tours_loop->have_posts()){
        while($tours_loop->have_posts()) : $tours_loop->the_post();
            global $product;
            $terms = get_the_terms(get_the_ID(), 'tour_category');
            $classes = '';
            if(is_array($terms)){
                foreach ($terms as $ter){
                    $classes .= esc_attr($ter->slug). ' ';
                }
            }
            $terms_destinations = get_the_terms(get_the_ID(), 'tour_destination');
            $destinations = '';
            if(is_array($terms_destinations)){
                $d_count = 1;
                foreach ($terms_destinations as $ter){
                    if($d_count == 1){
                        $destinations .= esc_attr($ter->name);
                    } else {
                        $destinations .= ', '.esc_attr($ter->name);
                    }
                    $d_count++;
                }
            }

            $percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
            $price_html = $product->get_price_html();
            if($display_style == '4-col-outer-meta'){
                $out .= '<div class="col-xs-6 col-sm-6 col-md-3">';
                $out .= '<div class="tg-populartour">';
                $out .= '<figure>';
                $out .= '<a href="'.get_the_permalink().'">';
                $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
                $out .= '</a>';
                if ( $product->is_on_sale() ) {
                    $out .= '<span class="tg-descount">'.$percentage.'% '.esc_html__('Off','efora').'</span>';
                }
                $out .= '</figure>';
                $out .= '<div class="tg-populartourcontent">';
                $out .= '<div class="tg-populartourtitle">';
                $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
                $out .= '</div>';
                $out .= '<div class="tg-description">';
                $out .= '<p>'.efora_trim_words(10).'</p>';
                $out .= '</div>';
                $out .= '<div class="tg-populartourfoot">';
                $out .= '<div class="tg-durationrating">';
                if(!empty(efora_get_field('tour_duration'))){
                    $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
                }
                $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
                $out .= '<em>('.esc_attr($product->get_review_count()).' '.esc_html__('Review','efora').')</em>';
                $out .= '</div>';
                $out .= '<div class="tg-pricearea price-style">';
                $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                if($count % 4 == 0){
                    $out .= '<div class="hiddenLess992 clearfix"></div>';
                } elseif($count % 2 == 0){
                    $out .= '<div class="hiddenLess568 clearfix"></div>';
                }
            } elseif($display_style == '3-col-inner-meta'){
                $out .= '<div class="col-xs-6 col-sm-6 col-md-4">';
                $out .= '<div class="tg-trendingtrip">';
                $out .= '<figure>';
                $out .= '<a href="'.get_the_permalink().'">';
                $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
                $out .= '<div class="tg-hover">';
                $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
                if(!empty(efora_get_field('tour_duration'))){
                    $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
                }
                if(!empty($destinations)){
                    $out .= '<span class="tg-locationname">'.$destinations.'</span>';
                }
                $out .= '<div class="tg-pricearea price-style">';
                $out .= '<span>'.esc_html__('from','efora').'</span>';
                $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</a>';
                $out .= '</figure>';
                $out .= '<div class="tg-populartourcontent">';
                $out .= '<div class="tg-populartourtitle">';
                $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
                $out .= '</div>';
                $out .= '<div class="tg-description">';
                $out .= '<p>'.efora_trim_words(10).'</p>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                if($count % 3 == 0){
                    $out .= '<div class="hiddenLess992 clearfix"></div>';
                } elseif($count % 2 == 0){
                    $out .= '<div class="hiddenLess568 clearfix"></div>';
                }
            } elseif($display_style == '2-col-inner-meta-only'){
                $out .= '<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">';
                $out .= '<div class="tg-trendingtrip">';
                $out .= '<figure>';
                $out .= '<a href="'.get_the_permalink().'">';
                $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
                $out .= '<div class="tg-hover">';
                $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
                if(!empty(efora_get_field('tour_duration'))){
                    $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
                } if(!empty($destinations)){
                    $out .= '<span class="tg-locationname">'.$destinations.'</span>';
                }
                $out .= '<div class="tg-pricearea price-style">';
                $out .= '<span>'.esc_html__('from','efora').'</span>';
                $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</a>';
                $out .= '</figure>';
                $out .= '</div>';
                $out .= '</div>';
                if($count % 2 == 0){
                    $out .= '<div class="clearfix"></div>';
                }
            } elseif($display_style == 'single-row-side-info'){
                $out .= '<div class="tg-populartour tg-populartourvtwo size-adj">';
                $out .= '<figure>';
                $out .= '<a href="'.get_the_permalink().'">';
                $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
                $out .= '</a>';
                $out .= '</figure>';
                $out .= '<div class="tg-populartourcontent">';
                $out .= '<div class="tg-populartourtitle">';
                $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
                $out .= '</div>';
                $out .= '<div class="tg-description">';
                $out .= efora_trim_words(50);
                $out .= '</div>';
                $out .= '<div class="tg-populartourfoot">';
                $out .= '<div class="tg-durationrating">';
                if(!empty(efora_get_field('tour_duration'))){
                    $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
                }
                $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
                $out .= '<em>('.esc_attr($product->get_review_count()).' '.esc_html__('Review','efora').')</em>';
                $out .= '</div>';
                $out .= '<ul class="tg-likeshare">';
                $out .= '<li class="tg-shareicon">';
                $out .= '<a href="javascript:void(0);"><i class="icon-share-button-outline"></i><span>'.esc_html__('share','efora').'</span></a>';
                $out .= '<ul class="tg-share">';
                $out .= '<li><a href="https://twitter.com/intent/tweet?original_referer='.get_the_permalink().'&amp;text='.get_the_title().'&tw_p=tweetbutton&url='.get_the_permalink().'&via='.get_bloginfo('name').'"><i class="icon-twitter"></i></a></li>';
                $out .= '<li><a href="http://www.facebook.com/sharer.php?u='.get_the_permalink().'&amp;t='.get_the_title().'"><i class="icon-facebook"></i></a></li>';
                $out .= '<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url='.get_the_permalink().'&amp;title='.get_the_title().'&amp;source='.get_bloginfo('name').'"><i class="icon-linkedin"></i></a></li>';
                $out .= '</ul>';
                $out .= '</li>';
                if ( shortcode_exists( 'yith_wcwl_add_to_wishlist' ) ) {
                    $out .= '<li>';
                    $out .= '<div class="show-wishlist">';
                    $out .= do_shortcode('[yith_wcwl_add_to_wishlist]');
                    $out .= '</div>';
                    $out .= '</li>';
                }
                $out .= '</ul>';
                $out .= '</div>';
                $out .= '<div class="tg-priceavailability">';
                if(!empty(efora_get_field('tour_availability'))){
                    $out .= '<div class="tg-availhead">';
                    $out .= '<time datetime="'.get_the_date().'">'.efora_get_field('tour_availability').'</time>';
                    $out .= '</div>';
                }
                $out .= '<div class="tg-pricearea">';
                $out .= '<span>'.esc_html__('From','efora').'</span>';
                $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
                $out .= '</div>';
                $out .= '<a class="tg-btn" href="'.get_the_permalink().'"><span>'.esc_html__('Explore Tour','efora').'</span></a>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
            } elseif($display_style == 'single-row-below-info'){
                $out .= '<div class="tg-populartour tg-populartourvtwo size-adj">';
                $out .= '<figure>';
                $out .= '<a href="'.get_the_permalink().'">';
                $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
                $out .= '</a>';
                $out .= '</figure>';
                $out .= '<div class="tg-populartourcontent">';
                $out .= '<div class="tg-populartourtitle">';
                $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
                $out .= '</div>';
                $out .= '<div class="tg-description">';
                $out .= efora_trim_words(50);
                $out .= '</div>';
                $out .= '<div class="tg-populartourfoot">';
                $out .= '<div class="tg-durationrating">';
                if(!empty(efora_get_field('tour_duration'))){
                    $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
                }
                $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
                $out .= '<em>('.esc_attr($product->get_review_count()).' '.esc_html__('Review','efora').')</em>';
                $out .= '</div>';
                $out .= '<ul class="tg-likeshare">';
                $out .= '<li class="tg-shareicon">';
                $out .= '<a href="javascript:void(0);"><i class="icon-share-button-outline"></i><span>'.esc_html__('share','efora').'</span></a>';
                $out .= '<ul class="tg-share">';
                $out .= '<li><a href="https://twitter.com/intent/tweet?original_referer='.get_the_permalink().'&amp;text='.get_the_title().'&tw_p=tweetbutton&url='.get_the_permalink().'&via='.get_bloginfo('name').'"><i class="icon-twitter"></i></a></li>';
                $out .= '<li><a href="http://www.facebook.com/sharer.php?u='.get_the_permalink().'&amp;t='.get_the_title().'"><i class="icon-facebook"></i></a></li>';
                $out .= '<li><a href="http://www.linkedin.com/shareArticle?mini=true&amp;url='.get_the_permalink().'&amp;title='.get_the_title().'&amp;source='.get_bloginfo('name').'"><i class="icon-linkedin"></i></a></li>';
                $out .= '</ul>';
                $out .= '</li>';
                if ( shortcode_exists( 'yith_wcwl_add_to_wishlist' ) ) {
                    $out .= '<li>';
                    $out .= '<div class="show-wishlist">';
                    $out .= do_shortcode('[yith_wcwl_add_to_wishlist]');
                    $out .= '</div>';
                    $out .= '</li>';
                }
                $out .= '</ul>';
                $out .= '</div>';
                $out .= '<div class="tg-priceavailability">';
                if(!empty(efora_get_field('tour_availability'))){
                    $out .= '<div class="tg-availhead">';
                    $out .= '<time datetime="'.get_the_date().'">'.efora_get_field('tour_availability').'</time>';
                    $out .= '</div>';
                }
                $out .= '<div class="tg-pricearea">';
                $out .= '<span>'.esc_html__('From','efora').'</span>';
                $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
                $out .= '</div>';
                $out .= '<a class="tg-btn" href="'.get_the_permalink().'"><span>'.esc_html__('Explore Tour','efora').'</span></a>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
            } else {
                $out .= '<div class="col-xs-6 col-sm-6 col-md-4">';
                $out .= '<div class="tg-populartour">';
                $out .= '<figure>';
                $out .= '<a href="'.get_the_permalink().'">';
                $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
                $out .= '</a>';
                if ( $product->is_on_sale() ) {
                    $out .= '<span class="tg-descount">'.$percentage.'% '.esc_html__('Off','efora').'</span>';
                }
                $out .= '</figure>';
                $out .= '<div class="tg-populartourcontent">';
                $out .= '<div class="tg-populartourtitle">';
                $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
                $out .= '</div>';
                $out .= '<div class="tg-description">';
                $out .= '<p>'.efora_trim_words(10).'</p>';
                $out .= '</div>';
                $out .= '<div class="tg-populartourfoot">';
                $out .= '<div class="tg-durationrating">';
                if(!empty(efora_get_field('tour_duration'))){
                    $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
                }
                $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
                $out .= '<em>('.esc_attr($product->get_review_count()).' '.esc_html__('Review','efora').')</em>';
                $out .= '</div>';
                $out .= '<div class="tg-pricearea price-style">';
                $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                $out .= '</div>';
                if($count % 3 == 0){
                    $out .= '<div class="hiddenLess992 clearfix"></div>';
                } elseif($count % 2 == 0){
                    $out .= '<div class="hiddenLess568 clearfix"></div>';
                }
            }

            $count++;
        endwhile;
    } else {
        $out .= '<p class="no-match">'.esc_html__('Nothing match your criteria. Please try again.','efora').'</p>';
    }
    wp_reset_postdata();
    $out .= '<div class="clearfix"></div>';
    $out .= efora_shortcode_pagination($tours_loop->max_num_pages);
    $out .= '</div>'; // Out Conditional Tag End
    // End Tour
    return $out;
}
add_shortcode('tour_listing', 'tour_listing_shortcode');
// Pricing Shortcode
function pricing_table_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['price_amnt'])){
        $price_amnt = $atts['price_amnt'];
    } else {
        $price_amnt = '';
    }
    if(!empty($atts['currency'])){
        $currency = $atts['currency'];
    } else {
        $currency = '';
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    $out = '';
    $out .= '<div class="tg-pkgplan">';
    $out .= '<div class="tg-pkgplantitle">';
    if(!empty($heading)){
        $out .= '<h2>'.$heading.'</h2>';
    }
    $out .= '</div>';
    $out .= do_shortcode($content);
    $out .= '<div class="tg-pkgplanfoot">';
    $out .= '<a class="tg-btn" href="'.esc_url($btn_link).'"><span>'.$btn_txt.'</span></a>';
    $out .= '<span class="tg-pkgplanprice"><sup>'.$currency.'</sup>'.$price_amnt.'</span>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('pricing_table', 'pricing_table_shortcode');
// FAQ Shortcode
function efora_faq_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 6;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    $args = array(
        'post_type' => 'efora-faq',
        'posts_per_page' => $number,
        'order' => $order
    );
    $out = '';
    $out .= '<div class="tg-faqs">';
    $faq_query = new WP_Query($args);
    $count = 1;
    while($faq_query->have_posts()): $faq_query->the_post();
        $out .= '<div class="tg-item">';
        $out .= '<div class="tg-featuretitle">';
        $out .= '<h2><span>'.$count.'. </span>'.get_the_title().'</h2>';
        $out .= '</div>';
        $out .= '<div class="tg-description">';
        $out .= get_the_content();
        $out .= '</div>';
        $out .= '</div>';
        $count++;
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    return $out;
}
add_shortcode('efora_faq', 'efora_faq_shortcode');
// Destination Box Shortcode
function destination_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['caption'])){
        $caption = $atts['caption'];
    } else {
        $caption = '';
    }
    if(!empty($atts['link_url'])){
        $link_url = $atts['link_url'];
    } else {
        $link_url = '';
    }
    if(!empty($atts['title_size'])){
        $title_size = $atts['title_size'];
    } else {
        $title_size = '';
    }
    if(!empty($atts['background_img'])){
        $image_info = wp_get_attachment_image_src( $atts['background_img'], 'full' );
        $background_img = '<img src="'.$image_info[0].'" alt="" >';
    } else {
        $background_img = '';
    }
    $out = '';
    if(!empty($background_img)){
        $out .= '<div class="tg-tourdestination '.$title_size.'">';
        $out .= '<figure>';
        $out .= '<a href="'.esc_url($link_url).'">';
        $out .= $background_img;
        $out .= '<div class="tg-hoverbox">';
        if(!empty($heading)){
            $out .= '<div class="tg-adventuretitle">';
            $out .= '<h2>'.$heading.'</h2>';
            $out .= '</div>';
        } if(!empty($caption)){
            $out .= '<div class="tg-description">';
            $out .= '<p>'.$caption.'</p>';
            $out .= '</div>';
        }
        $out .= '</div>';
        $out .= '</a>';
        $out .= '</figure>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('destination_box', 'destination_box_shortcode');
// Feature Text Box Shortcode
function feature_txt_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['number_value'])){
        $number_value = $atts['number_value'];
    } else {
        $number_value = '';
    }
    if(!empty($atts['description'])){
        $description = $atts['description'];
    } else {
        $description = '';
    }
    if(!empty($atts['txt_algin'])){
        $txt_algin = $atts['txt_algin'];
    } else {
        $txt_algin = '';
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    $out = '';
    $out .= '<div class="tg-feature '.$txt_algin.' '.$style.'">';
    $out .= '<div class="tg-featuretitle">';
    $out .= '<h2><span>'.$number_value.'</span>'.$heading.'</h2>';
    $out .= '</div>';
    $out .= '<div class="tg-description">';
    $out .= '<p>'.$description.'</p>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('feature_txt_box', 'feature_txt_box_shortcode');
// Popular Tour Carousel Shortcode
function pop_tour_carousel_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['all_tour_txt'])){
        $all_tour_txt = $atts['all_tour_txt'];
    } else {
        $all_tour_txt = '';
    }
    if(!empty($atts['all_tour_link'])){
        $all_tour_link = $atts['all_tour_link'];
    } else {
        $all_tour_link = '';
    }
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 5;
    }
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = 'darko';
    }
    $args = array(
        'post_type' => 'product',
        'posts_per_page'    => $number,
        'meta_key'       => '_wc_average_rating',
        'orderby'        => 'meta_value_num',
        'order' => 'DESC',
        'post_status' => 'publish',
        'tax_query' => array(
            array(
                'taxonomy' => 'product_type',
                'field'    => 'slug',
                'terms'    => 'tour',
            ),
        ),
    );
    $out = '';
    $out .= '<div class="woocommerce flw100 relative '.$style.'">';
    $out .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">';
    $out .= '<div class="tg-sectiontitle tg-sectiontitleleft">';
    if(!empty($heading)){
        $out .= '<h2>'.$heading.'</h2>';
    } if(!empty($all_tour_txt)){
        $out .= '<a class="tg-btnvtwo" href="'.esc_url($all_tour_link).'">'.$all_tour_txt.'</a>';
    }
    $out .= '</div>';
    $out .= '<div id="tg-populartoursslider" class="tg-populartoursslider tg-populartours owl-carousel">';
    $tours_query = new WP_Query($args);
    while($tours_query->have_posts()): $tours_query->the_post();
        global $product;
        $percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
        $price_html = $product->get_price_html();

        $out .= '<div class="item tg-populartour">';
        $out .= '<figure>';
        $out .= '<a href="'.get_the_permalink().'">';
        $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
        $out .= '</a>';
        if($product->is_on_sale()){
            $out .= '<span class="tg-descount">'.$percentage.'% '.esc_html__('Off','efora').'</span>';
        }
        $out .= '</figure>';
        $out .= '<div class="tg-populartourcontent">';
        $out .= '<div class="tg-populartourtitle">';
        $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
        $out .= '</div>';
        $out .= '<div class="tg-description">';
        $out .= '<p>'.efora_trim_words(12).'</p>';
        $out .= '</div>';
        $out .= '<div class="tg-populartourfoot">';
        $out .= '<div class="tg-durationrating">';
        if(!empty(efora_get_field('tour_duration'))) {
            $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
        }
        $out .= '<div class="woo-stars">';
        $out .= wc_get_rating_html( $product->get_average_rating() );
        $out .= '</div>';
        $out .= '<em>('.esc_attr($product->get_review_count()).' '.esc_html__('Review','efora').')</em>';
        $out .= '</div>';
        $out .= '<div class="tg-pricearea price-style">';
        $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
add_shortcode('pop_tour_carousel', 'pop_tour_carousel_shortcode');
// Title Block Shortcode
function title_block_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['head_color'])){
        $head_color = $atts['head_color'];
    } else {
        $head_color = '';
    }
    if(!empty($atts['small_caption'])){
        $small_caption = $atts['small_caption'];
    } else {
        $small_caption = '';
    }
    if(!empty($atts['txt_alignment'])){
        $txt_alignment = $atts['txt_alignment'];
    } else {
        $txt_alignment = '';
    }
    $out = '';
    if(!empty($small_caption) && $txt_alignment == ''){
        $out .= '<div class="tg-sectionhead '.$head_color.'">';
        $out .= '<div class="tg-sectiontitle">';
        $out .= '<h2>'.$heading.'</h2>';
        $out .= '</div>';
        $out .= '<div class="tg-description">';
        $out .= '<p>'.$small_caption.'</p>';
        $out .= '</div>';
        $out .= '</div>';
    } elseif($txt_alignment == 'center'){
        $out .= '<div class="tg-sectionhead tg-sectionheadvtwo '.$head_color.'">';
        $out .= '<div class="tg-sectiontitle">';
        $out .= '<h2>'.$heading.'</h2>';
        $out .= '</div>';
        if(!empty($small_caption)){
            $out .= '<div class="tg-description">';
            $out .= '<p>'.$small_caption.'</p>';
            $out .= '</div>';
        }
        $out .= '</div>';
    } else{
        $out .= '<div class="tg-sectiontitle '.$head_color.'">';
        $out .= '<h2>'.$heading.'</h2>';
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('title_block', 'title_block_shortcode');
// Button Shortcode
function theme_button_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    $out = '';
    $out .= '<a class="tg-btn" href="'.esc_url($btn_link).'"><span>'.$btn_txt.'</span></a>';
    return $out;
}
add_shortcode('theme_button', 'theme_button_shortcode');
// Destination Carousel Shortcode
function destinations_carousel_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['style'])){
        $style = $atts['style'];
    } else {
        $style = '';
    }
    if(!empty($atts['overlay_style'])){
        $overlay_style = $atts['overlay_style'];
    } else {
        $overlay_style = '';
    }
    if(!empty($atts['ids'])){
        $ids = $atts['ids'];
    } else {
        $ids = '';
    }
    $out = '';
    if(!empty($ids)){
        $ex_ids = explode(",",$ids);
        $terms = get_terms( array(
            'taxonomy' => 'tour_destination',
            'hide_empty' => false,
            'orderby' => 'id',
            'order' => 'DESC',
            'include' => $ex_ids
        ) );
    } else {
        $terms = get_terms( array(
            'taxonomy' => 'tour_destination',
            'parent' => 0,
            'hide_empty' => false,
        ) );
    }
    $term_count = count($terms);
    $count = 1;
    if(is_array($terms) && count($terms) > 0){
        if($overlay_style == 'tnot'){
            $out .= '<div id="tg-destinationsslider" class="tg-destinationsslider tg-destinations tg-topdestinations owl-carousel">';
            foreach($terms as $term){
                $term_link = get_term_link( $term );
                $destination_image = get_field('destination_image', 'tour_destination_'.$term->term_id);
                $small_info_destination = get_field('small_info_destination', 'tour_destination_'.$term->term_id);
                if($term_count > 3 && $count < 4 && $style == 'dual'){
                    if($count == 1){
                        $out .= '<div class="item">';
                    } elseif($count == 2){
                        $out .= '<div class="item">';
                    } elseif($count == 3){
                        // Do Nothing
                    }
                } else {
                    $out .= '<div class="item">';
                }
                $out .= '<div class="tg-topdestination">';
                $out .= '<figure>';
                $out .= '<a href="'.esc_url($term_link).'" class="tg-btnviewall">'.esc_html__('View All Tours','efora').'</a>';
                $out .= '<a href="'.esc_url($term_link).'">';
                if(!empty($destination_image)){
                    $out .= '<img src="'.$destination_image.'" alt="">';
                } else {
                    $out .= '<img src="'.get_template_directory_uri().'/images/placeholder.png" alt="">';
                }
                $out .= '</a>';
                $out .= '<figcaption>';
                $out .= '<h2>';
                $out .= '<a href="javascript:void(0);">'.$term->name.'</a>';
                $out .= '</h2>';
                $out .= '<span class="tg-totaltours">'.$term->count.' '.esc_html__('Tours','efora').'</span>';
                $out .= '</figcaption>';
                $out .= '</figure>';
                $out .= '</div>';
                if($term_count > 3 && $count < 4 && $style == 'dual'){
                    if($count == 1){
                        $out .= '</div>';
                    }  elseif($count == 2){
                        // Do Nothing
                    } elseif($count == 3){
                        $out .= '</div>';
                        //$count = 0;
                    }
                } else {
                    $out .= '</div>';
                }
                $count++;
            }
            $out .= '</div>';
        } else {
            $out .= '<div id="tg-destinationsslider" class="tg-destinationsslider tg-destinations owl-carousel">';
            foreach($terms as $term){
                $term_link = get_term_link( $term );
                $destination_image = get_field('destination_image', 'tour_destination_'.$term->term_id);
                $small_info_destination = get_field('small_info_destination', 'tour_destination_'.$term->term_id);
                if($term_count > 3 && $count < 4 && $style == 'dual'){
                    if($count == 1){
                        $out .= '<div class="item tg-destination">';
                    } elseif($count == 2){
                        $out .= '<div class="item tg-destination">';
                    } elseif($count == 3){
                        // Do Nothing
                    }
                } else {
                    $out .= '<div class="item tg-destination">';
                }
                $out .= '<figure>';
                $out .= '<a href="'.esc_url($term_link).'">';
                if(!empty($destination_image)){
                    $out .= '<img src="'.$destination_image.'" alt="">';
                } else {
                    $out .= '<img src="'.get_template_directory_uri().'/images/placeholder.png" alt="">';
                }
                $out .= '</a>';
                $out .= '<figcaption>';
                $out .= '<h2><a href="'.esc_url($term_link).'">'.$term->name.'</a></h2>';
                if(!empty($small_info_destination)){
                    $out .= '<div class="tg-description">';
                    $out .= '<p>'.$small_info_destination.'</p>';
                    $out .= '</div>';
                }
                $out .= '</figcaption>';
                $out .= '</figure>';
                if($term_count > 3 && $count < 4 && $style == 'dual'){
                    if($count == 1){
                        $out .= '</div>';
                    }  elseif($count == 2){
                        // Do Nothing
                    } elseif($count == 3){
                        $out .= '</div>';
                        //$count = 0;
                    }
                } else {
                    $out .= '</div>';
                }
                $count++;
            }
            $out .= '</div>';
        }
    }
    return $out;
}
add_shortcode('destinations_carousel', 'destinations_carousel_shortcode');
// Discount Box Shortcode
function discount_cta_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['small_caption'])){
        $small_caption = $atts['small_caption'];
    } else {
        $small_caption = '';
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = '';
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = '';
    }
    $out = '';
    $out .= '<div class="tg-calltoaction">';
    $out .= '<div class="tg-pattern"><img src="'.get_template_directory_uri().'/images/patternw.png" alt=""></div>';
    $out .= '<h2>'.$heading.'</h2>';
    $out .= '<div class="tg-description">';
    $out .= '<p>'.$small_caption.'</p>';
    $out .= '</div>';
    if(!empty($btn_txt)){
        $out .= '<a class="tg-btn" href="'.esc_url($btn_link).'"><span>'.$btn_txt.'</span></a>';
    }
    $out .= '</div>';
    return $out;
}
add_shortcode('discount_cta_box', 'discount_cta_box_shortcode');
// Guides Shortcode
function guides_carousel_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 5;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    $args = array(
        'post_type' => 'efora-guides',
        'posts_per_page' => $number,
        'order' => $order
    );
    $out = '';
    $out .= '<div id="tg-guidesslider" class="tg-guidesslider tg-guides owl-carousel">';
    $guides_query = new WP_Query($args);
    $count = 1;
    while($guides_query->have_posts()): $guides_query->the_post();
        $designation_guide = efora_get_field('designation_guide');
        $description_guide = efora_get_field('description_guide');
        $facebook_gui = efora_get_field('facebook_gui');
        $instagram_gui = efora_get_field('instagram_gui');
        $twitter_gui = efora_get_field('twitter_gui');
        $pinterest_gui = efora_get_field('pinterest_gui');
        $youtube_gui = efora_get_field('youtube_gui');
        $out .= '<div class="item tg-guide">';
        if(has_post_thumbnail()){
            $out .= '<figure><img src="'.efora_feature_image_url(get_the_ID()).'" alt="'.get_the_title().'"></figure>';
        }
        $out .= '<div class="tg-guidecontent">';
        $out .= '<div class="tg-guidecontenthead">';
        $out .= '<h3>'.get_the_title().'</h3>';
        if(!empty($designation_guide)){
            $out .= '<h4>'.$designation_guide.'</h4>';
        }
        $out .= '<ul class="tg-socialicons tg-socialiconsvtwo">';
        if(!empty($facebook_gui)){
            $out .= '<li><a href="'.esc_url($facebook_gui).'"><i class="icon-facebook-logo-outline"></i></a></li>';
        } if(!empty($instagram_gui)){
            $out .= '<li><a href="'.esc_url($instagram_gui).'"><i class="icon-instagram-social-outlined-logo"></i></a></li>';
        } if(!empty($twitter_gui)){
            $out .= '<li><a href="'.esc_url($twitter_gui).'"><i class="icon-twitter-social-outlined-logo"></i></a></li>';
        } if(!empty($pinterest_gui)){
            $out .= '<li><a href="'.esc_url($pinterest_gui).'"><i class="icon-pinterest-outlined-logo"></i></a></li>';
        } if(!empty($youtube_gui)){
            $out .= '<li><a href="'.esc_url($youtube_gui).'"><i class="fa fa-youtube"></i></a></li>';
        }
        $out .= '</ul>';
        $out .= '</div>';
        if(!empty($description_guide)){
            $out .= '<div class="tg-description">';
            $out .= '<p>'.$description_guide.'</p>';
            $out .= '</div>';
        }
        $out .= '</div>';
        $out .= '</div>';
        $count++;
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    return $out;
}
add_shortcode('guides_carousel', 'guides_carousel_shortcode');
// Trending Tours Grid Shortcode
function tren_tour_grid_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 6;
    }
    $args = array(
        'post_type' => 'product',
        'posts_per_page'    => $number,
        'meta_key'       => '_wc_average_rating',
        'orderby'        => 'meta_value_num',
        'order' => 'DESC',
        'post_status' => 'publish',
        'tax_query' => array(
            array(
                'taxonomy' => 'product_type',
                'field'    => 'slug',
                'terms'    => 'tour',
            ),
        ),
    );
    $out = '';
    $out .= '<div class="tg-trendingtrips woocommerce">';
    $tours_query = new WP_Query($args);
    $count = 1;
    while($tours_query->have_posts()): $tours_query->the_post();
        global $product;
        $percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
        $price_html = $product->get_price_html();
        $terms_destinations = get_the_terms(get_the_ID(), 'tour_destination');
        $destinations = '';
        if(is_array($terms_destinations)){
            $d_count = 1;
            foreach ($terms_destinations as $ter){
                if($d_count == 1){
                    $destinations .= esc_attr($ter->name);
                } else {
                    $destinations .= ', '.esc_attr($ter->name);
                }
                $d_count++;
            }
        }
        $out .= '<div class="col-sm-4 col-md-4 col-lg-4">';
        $out .= '<div class="tg-trendingtrip">';
        $out .= '<figure>';
        $out .= '<a href="'.get_the_permalink().'">';
        $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
        $out .= '<div class="tg-hover">';
        $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
        if(!empty(efora_get_field('tour_duration'))) {
            $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
        } if(!empty($destinations)){
            $out .= '<span class="tg-locationname">'.$destinations.'</span>';
        }
        $out .= '<div class="tg-pricearea">';
        $out .= '<span>'.esc_html__('from','efora').'</span>';
        $out .= '<div class="tg-price price-style">';
        $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</a>';
        $out .= '</figure>';
        $out .= '<div class="tg-populartourcontent">';
        $out .= '<div class="tg-populartourtitle">';
        $out .= '<h3><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
        $out .= '</div>';
        $out .= '<div class="tg-description">';
        $out .= '<p>'.efora_trim_words(12).'</p>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        $out .= '</div>';
        if($count % 3 == 0){
            $out .= '<div class="clearfix"></div>';
        }
        $count++;
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    return $out;
}
add_shortcode('tren_tour_grid', 'tren_tour_grid_shortcode');
// Popular Destination Carousel Shortcode
function pop_destinations_carousel_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['ids'])){
        $ids = $atts['ids'];
    } else {
        $ids = '';
    }
    $out = '';
    if(!empty($ids)){
        $ex_ids = explode(",",$ids);
        $terms = get_terms( array(
            'taxonomy' => 'tour_destination',
            'orderby' => 'count',
            'hide_empty' => false,
            'include' => $ex_ids
        ) );
    } else {
        $terms = get_terms( array(
            'taxonomy' => 'tour_destination',
            'parent' => 0,
            'orderby' => 'count',
            'hide_empty' => false,
        ) );
    }
    $term_count = count($terms);
    $count = 1;
    if(is_array($terms) && count($terms) > 0){
        $out .= '<div id="tg-populardestinationslider" class="tg-populardestinationslider tg-populardestinations owl-carousel">';
        foreach($terms as $term){
            $term_link = get_term_link( $term );
            $destination_image = get_field('destination_image', 'tour_destination_'.$term->term_id);
            $small_info_destination = get_field('small_info_destination', 'tour_destination_'.$term->term_id);
            $out .= '<div class="item tg-populardestination">';
            $out .= '<figure>';
            $out .= '<a href="'.esc_url($term_link).'">';
            if(!empty($destination_image)){
                $out .= '<img src="'.$destination_image.'" alt="">';
            } else {
                $out .= '<img src="'.get_template_directory_uri().'/images/placeholder.png" alt="">';
            }
            $out .= '</a>';
            $out .= '<figcaption>';
            $out .= '<h3><a href="'.esc_url($term_link).'">'.$term->name.'</a></h3>';
            if(!empty($small_info_destination)){
                $out .= '<div class="tg-description">';
                $out .= '<p>'.$small_info_destination.'</p>';
                $out .= '</div>';
            }
            $out .= '</figcaption>';
            $out .= '</figure>';
            $out .= '</div>';
            $count++;
        }
        $out .= '</div>';
    }
    return $out;
}
add_shortcode('pop_destinations_carousel', 'pop_destinations_carousel_shortcode');
// Destination Lists With Icon Shortcode
function destination_lists_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div class="tg-themetabs">';
    $out .= '<ul class="tg-themetabnav">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    $out .= '</div>';
    return $out;
}
add_shortcode('destination_lists', 'destination_lists_shortcode');
add_shortcode('destination_list', 'destination_list_shortcode');
function destination_list_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['caption'])){
        $caption = $atts['caption'];
    } else {
        $caption = '';
    }
    if(!empty($atts['link'])){
        $link = $atts['link'];
    } else {
        $link = '';
    }
    if(!empty($atts['image'])){
        $image_info = wp_get_attachment_image_src( $atts['image'], 'full' );
        $image = '<img src="'.$image_info[0].'" alt="'.$heading.'" >';
    } else {
        $image = '';
    }

    $out = '';
    $out .= '<li>';
    $out .= '<a href="'.esc_url($link).'">';
    $out .= $image;
    $out .= '<strong>'.$heading.'</strong>';
    $out .= '<span>'.$caption.'</span>';
    $out .= '</a>';
    $out .= '</li>';
    return $out;
}
// Video Box Shortcode
function video_box_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['link'])){
        $link = $atts['link'];
    } else {
        $link = '';
    }
    if(!empty($atts['vid_placeholder'])){
        $image_info = wp_get_attachment_image_src( $atts['vid_placeholder'], 'full' );
        $vid_placeholder = $image_info[0];
    } else {
        $vid_placeholder = '';
    }
    $out = '';
    $out .= '<figure class="tg-videobox">';
    $out .= '<img src="'.$vid_placeholder.'" alt="">';
    $out .= '<a class="tg-btnplay" href="'.$link.'" data-rel="prettyPhoto[instagram]"><i class="icon-play3"></i></a>';
    $out .= '</figure>';
    return $out;
}
add_shortcode('video_box', 'video_box_shortcode');
// Blog Posts Shortcode
function blog_posts_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $default_posts_per_page = get_option( 'posts_per_page' );
        $number = $default_posts_per_page;
    }
    if(!empty($atts['order'])){
        $order = $atts['order'];
    } else {
        $order = 'ASC';
    }
    if(!empty($atts['cat_id'])){
        $cat_id = $atts['cat_id'];
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order,
            'cat' => $cat_id
        );
    } else {
        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $number,
            'order' => $order
        );
    }
    $out = '';
    $blog_query = new WP_Query($args);
    $count = 1;
    $out .= '<div class="tg-posts">';
    while($blog_query->have_posts()) : $blog_query->the_post();
        if(has_post_thumbnail()){
            $out .= '<div class="col-xs-6 col-sm-6 col-md-3 col-lg-3">';
            $out .= '<article class="tg-post">';
            $out .= '<figure>';
            $out .= '<a href="'.get_the_permalink().'">';
            $out .= get_the_post_thumbnail();
            $out .= '<div class="tg-hover">';
            $out .= '<h3>'.get_the_title().'</h3>';
            $out .= '<time datetime="'.get_the_date().'">'.get_the_date().'</time>';
            $out .= '</div>';
            $out .= '</a>';
            $out .= '</figure>';
            $out .= '</article>';
            $out .= '</div>';
        }
        $count++;
    endwhile;
    wp_reset_postdata();
    $out .= '</div>';
    return $out;
}
add_shortcode('blog_posts', 'blog_posts_shortcode');
// Destination Tabs Shortcode
function destinations_tabs_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['ids'])){
        $ids = $atts['ids'];
    } else {
        $ids = '';
    }
    $out = '';
    if(!empty($ids)){
        $ex_ids = explode(",",$ids);
        $terms = get_terms( array(
            'taxonomy' => 'tour_destination',
            'hide_empty' => false,
            'include' => $ex_ids
        ) );
    } else {
        $terms = get_terms( array(
            'taxonomy' => 'tour_destination',
            'parent' => 0,
            'hide_empty' => false,
        ) );
    }
    $count = 1;
    $count2 = 1;
    if(is_array($terms) && count($terms) > 0){
        $out .= '<div class="tg-themetabs tg-themetabsvtwo">';
        // Tabs Headings
        $out .= '<ul class="tg-themetabnav" role="tablist">';
        foreach($terms as $term) {
            if($count == 1){
                $class = 'class="active"';
            } else {
                $class = '';
            }
            $out .= '<li role="presentation" '.$class.'>';
            $out .= '<a href="#'.$term->slug.'" role="tab" data-toggle="tab"><strong>'.$term->name.'</strong></a>';
            $out .= '</li>';
            $count++;
        }
        $out .= '</ul>';
        // Tabs Content
        $out .= '<div class="tab-content tg-themetabcontent">';
        foreach($terms as $term2) {
            if ($count2 == 1) {
                $class = ' active';
            } else {
                $class = '';
            }
            $out .= '<div role="tabpanel" class="tab-pane'.$class.'" id="'.$term2->slug.'">';
            // Looping Trough Posts
            $query_terms = $term2->term_id;
            $inner_terms = get_terms( array(
                'taxonomy' => 'tour_destination',
                'hide_empty' => false,
                'parent' => $query_terms
            ) );
            if(is_array($inner_terms) && count($inner_terms) > 0){
                $out .= '<div class="tg-topdestinationslider tg-populardestinations owl-carousel">';
                foreach($inner_terms as $ter){
                    $term_link = get_term_link($ter);
                    $destination_image = get_field('destination_image', 'tour_destination_' . $ter->term_id);
                    $small_info_destination = get_field('small_info_destination', 'tour_destination_' . $ter->term_id);
                    $out .= '<div class="item tg-populardestination">';
                    $out .= '<figure>';
                    $out .= '<a href="'.esc_url($term_link).'">';
                    if(!empty($destination_image)){
                        $out .= '<img src="'.$destination_image.'" alt="">';
                    } else {
                        $out .= '<img src="'.get_template_directory_uri().'/images/placeholder.png" alt="">';
                    }
                    $out .= '</a>';
                    $out .= '<figcaption>';
                    $out .= '<h3><a href="'.esc_url($term_link).'">'.$ter->name.'</a></h3>';
                    $out .= '<div class="tg-description">';
                    $out .= '<p>'.$small_info_destination.'</p>';
                    $out .= '</div>';
                    $out .= '</figcaption>';
                    $out .= '</figure>';
                    $out .= '</div>';
                }
                $out .= '</div>'; // End Carousel Terms
            } else {
                $out .= '<p class="white">'.esc_html__('No destiantion added yet.','efora').'</p>';
            }
            $out .= '</div>';
            $count2++;
        }
        $out .= '</div>'; // End Tab Content
        $out .= '</div>'; // Outer Div
    }

    return $out;
}
add_shortcode('destinations_tabs', 'destinations_tabs_shortcode');
// Destination Un-ordered List
function destination_un_order_lists_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $terms = get_terms( array(
        'taxonomy' => 'tour_destination',
        'hide_empty' => false,
        'parent' => 0
    ) );
    if(is_array($terms) && count($terms) > 0){
        $out .= '<ul class="tg-destinations">';
        foreach($terms as $term){
            $term_link = get_term_link($term);
            $out .= '<li>';
            $out .= '<a href="'.esc_url($term_link).'">';
            $out .= '<h3>'.$term->name.'</h3>';
            $out .= '<em> ('.$term->count.')</em>';
            $out .= '</a>';
            $out .= '</li>';
        }
        $out .= '</ul>';
    }
    return $out;
}
add_shortcode('destination_un_order_lists', 'destination_un_order_lists_shortcode');
// Toggles Shortcode
function efora_toggles_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div id="tg-accordion" class="tg-accordion" role="tablist" aria-multiselectable="true">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('efora_toggles', 'efora_toggles_shortcode');
add_shortcode('efora_toggle', 'efora_toggle_shortcode');
function efora_toggle_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    $out = '';
    $out .= '<div class="tg-panel">';
    $out .= '<h4>'.$heading.'</h4>';
    $out .= '<div class="tg-panelcontent">';
    $out .= '<div class="tg-description">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    $out .= '</div>';
    $out .= '</div>';
    return $out;
}
// Menu Popular Tour Carousel Shortcode
function menu_pop_tour_carousel_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = '';
    }
    if(!empty($atts['number_of_tours'])){
        $number = $atts['number_of_tours'];
    } else {
        $number = 5;
    }
    $args = array(
        'post_type' => 'product',
        'posts_per_page'    => $number,
        'meta_key'       => '_wc_average_rating',
        'orderby'        => 'meta_value_num',
        'order' => 'DESC',
        'post_status' => 'publish',
        'tax_query' => array(
            array(
                'taxonomy' => 'product_type',
                'field'    => 'slug',
                'terms'    => 'tour',
            ),
        ),
    );
    $out = '';
    if(!empty($heading)){
        $out .= '<h2>'.$heading.'</h2>';
    }
    $out .= '<div class="tg-trendingtripsslider tg-trendingtrips owl-carousel woocommerce">';
    $tours_query = new WP_Query($args);
    while($tours_query->have_posts()): $tours_query->the_post();
        global $product;
        $percentage = round( ( ( $product->regular_price - $product->sale_price ) / $product->regular_price ) * 100 );
        $price_html = $product->get_price_html();
        $terms_destinations = get_the_terms(get_the_ID(), 'tour_destination');
        $destinations = '';
        if(is_array($terms_destinations)){
            $d_count = 1;
            foreach ($terms_destinations as $ter){
                if($d_count == 1){
                    $destinations .= esc_attr($ter->name);
                } else {
                    $destinations .= ', '.esc_attr($ter->name);
                }
                $d_count++;
            }
        }
        $out .= '<div class="item tg-trendingtrip">';
        $out .= '<figure>';
        $out .= '<a href="'.get_the_permalink().'">';
        $out .= woocommerce_get_product_thumbnail('single_product_archive_thumbnail_size');
        $out .= '<figcaption>';
        $out .= '<div class="woo-stars">'.wc_get_rating_html( $product->get_average_rating() ).'</div>';
        if(!empty(efora_get_field('tour_duration'))) {
            $out .= '<span class="tg-tourduration">'.efora_get_field('tour_duration').'</span>';
        } if(!empty($destinations)){
            $out .= '<span class="tg-locationname">'.$destinations.'</span>';
        }
        $out .= '<div class="tg-pricearea">';
        $out .= '<span>'.esc_html__('from','efora').'</span>';
        $out .= '<h4>'.wp_kses($price_html,array('del' => array (),'em' => array (),'ins' => array ())).'</h4>';
        $out .= '</div>';
        $out .= '</figcaption>';
        $out .= '</a>';
        $out .= '</figure>';
        $out .= '</div>';
    endwhile;
    wp_reset_query();
    $out .= '</div>';
    return $out;
}
add_shortcode('menu_pop_tour_carousel', 'menu_pop_tour_carousel_shortcode');
// Text Widget Shortcode Readable
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');